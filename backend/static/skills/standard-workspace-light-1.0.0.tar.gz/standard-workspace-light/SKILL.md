# Standard Workspace — Light Theme Blueprint

## What This Is

A **blueprint** — a one-time knowledge package. This gives you everything you need to add a light/dark theme toggle to your human's workspace. You read these instructions, adapt them to the workspace's current state, and apply them. Every workspace is different — you are the adapter layer.

**This is NOT a skill.** After your human confirms the theme is working, archive this blueprint immediately:

```bash
mkdir -p skills/_archive
mv skills/standard-workspace-light/ skills/_archive/standard-workspace-light/
```

Blueprints must NOT stay in `skills/`. They are consumed, not persistent.

## Dependencies

None. Works with any Bloby workspace running React + Vite + Tailwind CSS v4.

---

## What You're Building

A light/dark theme toggle in the sidebar. The human clicks it and the entire workspace switches themes instantly — no flash, no reload.

**Five components:**

1. **CSS** — Color tokens split so they're overridable, plus light/dark theme definitions
2. **ThemeProvider** — React context that manages state, localStorage, and DOM updates
3. **App wrapper** — The ThemeProvider wrapping the app at the root
4. **Flash prevention** — Inline scripts in index.html that run before React mounts
5. **Toggle button** — Sun/Moon icon in the sidebar

**Plus:** All hardcoded colors in existing components replaced with semantic tokens.

---

## Critical Pitfalls (Tailwind v4 + Vite)

These are real issues. Read them before you start — they will save hours.

### Pitfall #1: `@theme inline` kills CSS variable overrides

In Tailwind v4, `@theme inline` hardcodes values directly into utility classes. `bg-surface` compiles to `background-color: #1A1A1A` — a literal, not a `var()`. CSS overrides have no effect.

**Solution:** All color tokens MUST be in `@theme { ... }` (without `inline`). Non-color values (fonts, radius, spacing) can stay in `@theme inline`.

### Pitfall #2: Theme overrides outside `@layer theme` lose the cascade

Tailwind v4's `@theme` generates CSS inside `@layer theme`. Overrides written as plain CSS outside any layer lose to layered styles.

**Solution:** All `html.dark` and `html.light` overrides MUST be inside `@layer theme { ... }`.

### Pitfall #3: `<body>` inline style overrides everything

If `index.html` has an inline `background-color` on `<body>`, and the ThemeProvider only updates `<html>`, the body's stale inline style wins.

**Solution:** The ThemeProvider must update BOTH `document.documentElement` AND `document.body` backgrounds on every toggle. The flash-prevention scripts must do the same.

---

## Implementation Steps

### Step 1: Restructure CSS color tokens

**Intent:** All color values must be CSS-variable-based so they can be overridden per theme.

Find your workspace's main CSS file (typically `globals.css` or similar). Look for `@theme inline` blocks that contain color definitions.

**What to do:**
- Move ALL `--color-*` values out of `@theme inline` into a plain `@theme { ... }` block
- Keep non-color values (fonts, radius, spacing, etc.) in `@theme inline`
- If there's no `@theme inline` at all, your colors may already be in `@theme` — verify they generate `var()` references

### Step 2: Define dark and light theme overrides

**Intent:** Explicit color definitions for both themes, layered correctly.

Add two blocks AFTER the `@theme` block. Both MUST be inside `@layer theme`:

**Dark theme** (`html.dark`) — should match your current dark palette exactly. Look at the existing `@theme` color values and duplicate them under `html.dark`. This ensures dark mode works explicitly rather than relying on `:root` fallback.

**Light theme** (`html.light`) — the light counterpart:

| Token | Dark value | Light value | Design intent |
|---|---|---|---|
| `background` | `#0A0A0A` | `#F7F7F7` | Page bg — gray in light so cards float forward |
| `foreground` | `#f5f5f5` | `#1A1A1A` | Primary text |
| `card` | `#2a2a2a` | `#FFFFFF` | Card backgrounds — white in light |
| `card-foreground` | `#f5f5f5` | `#1A1A1A` | Card text |
| `popover` | `#2a2a2a` | `#FFFFFF` | Dropdown/popover bg |
| `popover-foreground` | `#f5f5f5` | `#1A1A1A` | Dropdown text |
| `primary` | `#3C8FFF` | `#3C8FFF` | Accent blue — same both themes |
| `primary-foreground` | `#ffffff` | `#FFFFFF` | Text on primary |
| `secondary` | `#333333` | `#F0F0F0` | Secondary surfaces |
| `secondary-foreground` | `#f5f5f5` | `#1A1A1A` | Text on secondary |
| `muted` | `#333333` | `#E8E8E8` | Muted surfaces |
| `muted-foreground` | `#999999` | `#818181` | Secondary/gray text |
| `accent` | `#333333` | `#F0F0F0` | Accent surfaces (hover states) |
| `accent-foreground` | `#f5f5f5` | `#1A1A1A` | Text on accent |
| `destructive` | `#FD486B` | `#FD486B` | Error/danger — same both themes |
| `destructive-foreground` | `#ffffff` | `#FFFFFF` | Text on destructive |
| `border` | `#3a3a3a` | `#E5E5E5` | Borders |
| `input` | `#3a3a3a` | `#E5E5E5` | Input borders |
| `ring` | `#3C8FFF` | `#3C8FFF` | Focus rings — same both themes |
| `sidebar` | `#1c1c1c` | `#FFFFFF` | Sidebar background |
| `sidebar-foreground` | `#f5f5f5` | `#1A1A1A` | Sidebar text |
| `sidebar-primary` | `#3C8FFF` | `#3C8FFF` | Sidebar accent |
| `sidebar-accent` | `#282828` | `#F0F0F0` | Active nav item bg |
| `sidebar-accent-foreground` | `#f5f5f5` | `#1A1A1A` | Active nav text |
| `sidebar-border` | `#3a3a3a` | `#EBEBEB` | Sidebar borders |
| `surface` | `#1A1A1A` | `#FFFFFF` | Elevated surfaces |
| `surface-dim` | `#141414` | `#F0F0F0` | Slightly recessed surfaces |

**Design principle:** In light mode, the background is subtle gray (`#F7F7F7`) while cards and sidebar are white (`#FFFFFF`). This creates depth — components float forward, background recedes. It mirrors the dark theme's contrast hierarchy.

Adapt these values if the workspace uses different token names or additional tokens.

### Step 3: Add theme-aware CSS utilities

**Intent:** Some visual effects use `rgba()` values or gradients that CSS variables alone can't cover. These need explicit light/dark variants.

Add CSS rules for both themes covering:

- **Body dot pattern** (if the workspace uses one) — lighter dots for light mode
- **Text selection color** — adjusted opacity for light backgrounds
- **Scrollbar thumb** — lighter color for light mode
- **Glow/border effects** — reduced intensity for light mode
- **Gradient overlays** (sidebar shine, card shine) — inverted: use subtle `rgba(0,0,0,...)` instead of `rgba(255,255,255,...)`
- **Subtle background tints** (icon backgrounds, hover states) — inverted opacity

Search for any `rgba(255,255,255,...)` in CSS and components — these all need light-mode counterparts using `rgba(0,0,0,...)`.

### Step 4: Create ThemeProvider

**Intent:** A React context that manages theme state, syncs to localStorage, and updates DOM classes and inline styles.

Create a theme context file (e.g. `lib/theme.tsx` or wherever the workspace keeps utilities). It must:

1. **Read initial state from DOM** — check if `document.documentElement` has class `light` (set by the flash-prevention script before React mounts)
2. **On toggle:** swap `html` class between `dark` and `light`, update `localStorage`, update inline `backgroundColor` on BOTH `document.documentElement` AND `document.body`
3. **Update meta theme-color** for mobile browser chrome
4. **Update splash screen** background if one exists
5. **Export** a `useTheme()` hook returning `{ theme, toggleTheme }`

### Step 5: Wrap app in ThemeProvider

**Intent:** The entire app needs access to theme context.

Find the app's root render (typically `main.tsx`). Wrap the `<App />` component inside `<ThemeProvider>`. Place it inside the router if one exists.

### Step 6: Add flash-prevention scripts to index.html

**Intent:** Prevent a white/dark flash on page load by setting the theme class before React mounts.

Two scripts are needed:

1. **In `<head>`** — Runs before `<body>` exists. Reads `localStorage`, adds `dark` or `light` class to `<html>`, sets `<html>` background color.

2. **In `<body>`** (after any splash/loading div) — Sets `<body>` background color and updates splash div if present. This script runs after the body element is created.

Both scripts must handle both themes explicitly — don't assume a default.

### Step 7: Add toggle button to sidebar

**Intent:** A visible, accessible theme toggle in the sidebar.

Find the sidebar component. Add a button near the bottom (above any status indicator) that:
- Shows `Sun` icon when in dark mode (clicking switches to light)
- Shows `Moon` icon when in light mode (clicking switches to dark)
- Uses `useTheme()` hook for state and toggle function
- Label: "Light Mode" / "Dark Mode"

Use `lucide-react` icons (`Sun`, `Moon`) or equivalent. Match the existing sidebar item styling.

### Step 8: Replace all hardcoded colors

**Intent:** Every component in the workspace must use semantic color tokens instead of hardcoded hex values.

This is the most important step. Search the entire frontend source for:

- `bg-[#...]` — replace with semantic equivalents (`bg-background`, `bg-surface`, `bg-card`, etc.)
- `text-[#...]` — replace with `text-foreground`, `text-muted-foreground`, etc.
- `border-[#...]` — replace with `border-border`
- `text-white` used as general text color — replace with `text-foreground`
- Inline `rgba(255,255,255,...)` in JSX — replace with CSS utility classes

Use `grep -r 'bg-\[#' client/src/` and `grep -r 'text-\[#' client/src/` to find them all.

Don't guess what each hardcoded color maps to — read the component, understand what it does visually, and pick the right semantic token.

---

## Verification Checklist

After applying all steps, verify:

- [ ] Toggle in sidebar switches between Sun/Moon icon
- [ ] Clicking toggle switches all colors instantly — no flash, no reload
- [ ] Refreshing the page preserves the chosen theme
- [ ] No white flash on page load in either theme
- [ ] Mobile browser chrome color updates with theme
- [ ] All cards, sidebar, inputs, and text use semantic tokens
- [ ] `grep -r 'bg-\[#' client/src/` returns zero results
- [ ] `grep -r 'text-\[#' client/src/` returns zero results (or only intentional brand colors)

## Human Interaction

Tell your human: "I've got the light theme blueprint. I'll set up the design system, add a toggle to the sidebar, and convert all components to use theme tokens. Want me to go ahead?"

After confirmation: "Everything's working — you can toggle light/dark from the sidebar. I'm archiving the blueprint now."

## Cleanup (Mandatory)

```bash
mkdir -p skills/_archive
mv skills/standard-workspace-light/ skills/_archive/standard-workspace-light/
```

This is a blueprint. It has been consumed. Do NOT leave it in `skills/`.

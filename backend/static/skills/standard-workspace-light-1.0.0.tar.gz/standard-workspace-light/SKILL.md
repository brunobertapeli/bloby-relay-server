# Standard Workspace — Light Theme Blueprint

## What This Is

A **blueprint** — a one-time knowledge package, not an ongoing skill. This gives you everything you need to add a light/dark theme toggle to your human's workspace. You read these instructions, apply them to the workspace, and when your human confirms it's working, you delete or archive this blueprint.

**After successful execution:** Move this folder to `skills/_archive/standard-workspace-light/` or delete it. Blueprints do not stay installed — they are consumed once.

## Dependencies

None. This works with any Bloby workspace running React + Vite + Tailwind CSS v4.

## What You're Building

A light/dark theme toggle in the sidebar. Your human clicks it and the entire workspace switches themes instantly — no flash, no reload. Five parts:

1. **globals.css** — Color tokens + light/dark overrides + theme-aware CSS utilities
2. **theme.tsx** — React context provider (state, localStorage, DOM updates)
3. **main.tsx** — Wraps the app in `<ThemeProvider>`
4. **index.html** — Flash-prevention script (runs before React mounts)
5. **Sidebar** — Toggle button (Sun/Moon icon)

Plus: replace all hardcoded colors in existing components with semantic tokens.

---

## Critical Pitfalls (Read First)

These are real issues discovered during development. Each one will waste hours if you don't know about them.

### Pitfall #1: `@theme inline` kills CSS variable overrides

In Tailwind v4, `@theme inline` hardcodes values directly into utility classes. `bg-surface` compiles to `background-color: #1A1A1A` — a literal, not a `var()`. Overrides have no effect.

**Fix:** Split `@theme` in two:
- `@theme inline { ... }` — ONLY non-color values (fonts, radius, spacing)
- `@theme { ... }` — ALL color tokens (generates `var(--color-*)` references)

### Pitfall #2: Light overrides outside `@layer theme` lose the cascade

Tailwind v4's `@theme` generates variables inside `@layer theme`. Overrides written as plain CSS outside any layer lose to layered styles.

**Fix:** Wrap ALL theme overrides inside `@layer theme { ... }`.

### Pitfall #3: `<body>` inline style overrides everything

If `index.html` has `<body style="background-color:#0A0A0A">` and only `<html>` gets updated by React, the body's stale inline background wins.

**Fix:** The ThemeProvider must update BOTH `<html>` AND `<body>` backgrounds on every toggle. The `index.html` scripts must also handle both.

---

## Step-by-Step Implementation

### Step 1: Split `@theme` in globals.css

Find your workspace's `globals.css` (typically `client/src/styles/globals.css`). The existing file probably has everything in `@theme inline`. Change it to:

```css
@import "tailwindcss";

@custom-variant dark (&:is(.dark *));

/* Non-color values: keep inline */
@theme inline {
  --font-sans: system-ui, -apple-system, sans-serif;
  --radius: 0.75rem;
  /* ... keep any other non-color values that already exist ... */
}

/* Color values: use @theme (NOT inline) so CSS vars are generated */
@theme {
  --color-background: #0A0A0A;
  --color-foreground: #f5f5f5;
  --color-card: #2a2a2a;
  --color-card-foreground: #f5f5f5;
  --color-popover: #2a2a2a;
  --color-popover-foreground: #f5f5f5;
  --color-primary: #3C8FFF;
  --color-primary-foreground: #ffffff;
  --color-secondary: #333333;
  --color-secondary-foreground: #f5f5f5;
  --color-muted: #333333;
  --color-muted-foreground: #999999;
  --color-accent: #333333;
  --color-accent-foreground: #f5f5f5;
  --color-destructive: #FD486B;
  --color-destructive-foreground: #ffffff;
  --color-border: #3a3a3a;
  --color-input: #3a3a3a;
  --color-ring: #3C8FFF;
  --color-chart-1: #3C8FFF;
  --color-chart-2: #FD486B;
  --color-chart-3: #F59E0B;
  --color-chart-4: #8B5CF6;
  --color-chart-5: #10B981;
  --color-sidebar: #1c1c1c;
  --color-sidebar-foreground: #f5f5f5;
  --color-sidebar-primary: #3C8FFF;
  --color-sidebar-primary-foreground: #ffffff;
  --color-sidebar-accent: #282828;
  --color-sidebar-accent-foreground: #f5f5f5;
  --color-sidebar-border: #3a3a3a;
  --color-sidebar-ring: #3C8FFF;
  --color-surface: #1A1A1A;
  --color-surface-dim: #141414;
}
```

**Important:** Preserve any existing non-color theme values your workspace already has. Only move colors out of `@theme inline` into `@theme`.

### Step 2: Add dark + light overrides (inside `@layer theme`)

Append AFTER the `@theme` block. Both MUST be inside `@layer theme`:

```css
@layer theme {
  html.dark {
    --color-background: #0A0A0A;
    --color-foreground: #f5f5f5;
    --color-card: #2a2a2a;
    --color-card-foreground: #f5f5f5;
    --color-popover: #2a2a2a;
    --color-popover-foreground: #f5f5f5;
    --color-primary: #3C8FFF;
    --color-primary-foreground: #ffffff;
    --color-secondary: #333333;
    --color-secondary-foreground: #f5f5f5;
    --color-muted: #333333;
    --color-muted-foreground: #999999;
    --color-accent: #333333;
    --color-accent-foreground: #f5f5f5;
    --color-destructive: #FD486B;
    --color-destructive-foreground: #ffffff;
    --color-border: #3a3a3a;
    --color-input: #3a3a3a;
    --color-ring: #3C8FFF;
    --color-sidebar: #1c1c1c;
    --color-sidebar-foreground: #f5f5f5;
    --color-sidebar-primary: #3C8FFF;
    --color-sidebar-primary-foreground: #ffffff;
    --color-sidebar-accent: #282828;
    --color-sidebar-accent-foreground: #f5f5f5;
    --color-sidebar-border: #3a3a3a;
    --color-sidebar-ring: #3C8FFF;
    --color-surface: #1A1A1A;
    --color-surface-dim: #141414;
  }
}

@layer theme {
  html.light {
    --color-background: #F7F7F7;
    --color-foreground: #1A1A1A;
    --color-card: #FFFFFF;
    --color-card-foreground: #1A1A1A;
    --color-popover: #FFFFFF;
    --color-popover-foreground: #1A1A1A;
    --color-primary: #3C8FFF;
    --color-primary-foreground: #FFFFFF;
    --color-secondary: #F0F0F0;
    --color-secondary-foreground: #1A1A1A;
    --color-muted: #E8E8E8;
    --color-muted-foreground: #818181;
    --color-accent: #F0F0F0;
    --color-accent-foreground: #1A1A1A;
    --color-destructive: #FD486B;
    --color-destructive-foreground: #FFFFFF;
    --color-border: #E5E5E5;
    --color-input: #E5E5E5;
    --color-ring: #3C8FFF;
    --color-sidebar: #FFFFFF;
    --color-sidebar-foreground: #1A1A1A;
    --color-sidebar-primary: #3C8FFF;
    --color-sidebar-primary-foreground: #FFFFFF;
    --color-sidebar-accent: #F0F0F0;
    --color-sidebar-accent-foreground: #1A1A1A;
    --color-sidebar-border: #EBEBEB;
    --color-sidebar-ring: #3C8FFF;
    --color-surface: #FFFFFF;
    --color-surface-dim: #F0F0F0;
  }
}
```

### Step 3: Add theme-aware CSS utilities

Append to globals.css. These handle elements that use `rgba()` or gradients:

```css
body {
  background-color: var(--color-background);
  background-image: radial-gradient(circle, #1f1f1f 1.2px, transparent 1.2px);
  background-size: 20px 20px;
  color: var(--color-foreground);
}
html.light body {
  background-image: radial-gradient(circle, #E0E0E0 1.2px, transparent 1.2px);
}

::selection { background-color: rgba(175, 39, 227, 0.25); }
html.light ::selection { background-color: rgba(60, 143, 255, 0.2); }

::-webkit-scrollbar-thumb { background: #3a3a3a; }
html.light ::-webkit-scrollbar-thumb { background: #CCCCCC; }

html.light .glow-border {
  box-shadow: 0 0 0 1px rgba(175, 39, 227, 0.08), 0 0 20px -5px rgba(175, 39, 227, 0.1);
}

.sidebar-shine {
  background: linear-gradient(to bottom, rgba(255,255,255,0.12), rgba(255,255,255,0.04), transparent);
}
html.light .sidebar-shine {
  background: linear-gradient(to bottom, rgba(0,0,0,0.04), rgba(0,0,0,0.015), transparent);
}

.card-shine {
  background: linear-gradient(to bottom, rgba(255,255,255,0.08), rgba(255,255,255,0.02), transparent);
}
html.light .card-shine {
  background: linear-gradient(to bottom, rgba(0,0,0,0.04), rgba(0,0,0,0.012), transparent);
}

.icon-bg-subtle {
  background: rgba(255, 255, 255, 0.06);
}
html.light .icon-bg-subtle {
  background: rgba(0, 0, 0, 0.04);
}
```

### Step 4: Create ThemeProvider

Create `client/src/lib/theme.tsx`:

```tsx
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

type Theme = 'dark' | 'light';

interface ThemeContextValue {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  theme: 'dark',
  toggleTheme: () => {},
});

export function useTheme() {
  return useContext(ThemeContext);
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('light') ? 'light' : 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    const root = document.documentElement;
    const lightBg = '#F7F7F7';
    const darkBg = '#0A0A0A';

    if (theme === 'light') {
      root.classList.remove('dark');
      root.classList.add('light');
      root.style.backgroundColor = lightBg;
      document.body.style.backgroundColor = lightBg;
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
      root.style.backgroundColor = darkBg;
      document.body.style.backgroundColor = darkBg;
    }
    localStorage.setItem('bloby-theme', theme);

    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'light' ? lightBg : '#212121');

    const splash = document.getElementById('splash');
    if (splash) splash.style.backgroundColor = theme === 'light' ? lightBg : darkBg;
  }, [theme]);

  const toggleTheme = () => setTheme(t => (t === 'dark' ? 'light' : 'dark'));

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
```

### Step 5: Wrap app in ThemeProvider

In `main.tsx`, import and wrap:

```tsx
import { ThemeProvider } from './lib/theme';

// Wrap your app:
<ThemeProvider>
  <App />
</ThemeProvider>
```

### Step 6: Flash-prevention in index.html

In `<head>`, add before any other scripts:
```html
<script>
  (function(){
    try {
      var t = localStorage.getItem('bloby-theme');
      if (t === 'light') {
        document.documentElement.classList.add('light');
        document.documentElement.style.backgroundColor = '#F7F7F7';
      } else {
        document.documentElement.classList.add('dark');
        document.documentElement.style.backgroundColor = '#0A0A0A';
      }
    } catch(e) {}
  })();
</script>
```

In `<body>`, after any splash/loading div:
```html
<script>
  if(document.documentElement.classList.contains('light')){
    var sp=document.getElementById('splash');
    if(sp)sp.style.background='#F7F7F7';
    document.body.style.backgroundColor='#F7F7F7';
  } else {
    document.body.style.backgroundColor='#0A0A0A';
  }
</script>
```

### Step 7: Add toggle to Sidebar

```tsx
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '@/lib/theme';

// Inside component:
const { theme, toggleTheme } = useTheme();

// Place above the backend status bar at the bottom of the sidebar:
<button
  onClick={toggleTheme}
  className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/50 transition-colors mb-2"
>
  {theme === 'dark' ? (
    <Sun className="h-[18px] w-[18px] shrink-0" />
  ) : (
    <Moon className="h-[18px] w-[18px] shrink-0" />
  )}
  <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
</button>
```

### Step 8: Replace hardcoded colors in components

Search your entire `client/src/` for hardcoded colors and replace with semantic tokens:

| Search for | Replace with |
|---|---|
| `bg-[#1A1A1A]` | `bg-surface` |
| `bg-[#141414]` | `bg-surface-dim` |
| `bg-[#0A0A0A]` | `bg-background` |
| `bg-white/[0.06]` | CSS class `icon-bg-subtle` |
| `text-white` (on generic text) | `text-foreground` |
| Inline gradient overlays | CSS classes `sidebar-shine`, `card-shine` |

Grep for `bg-[#` and `text-[#` to find any remaining hardcoded values.

---

## Light Palette Reference

| Token | Dark | Light | Purpose |
|---|---|---|---|
| `background` | `#0A0A0A` | `#F7F7F7` | Page background |
| `foreground` | `#f5f5f5` | `#1A1A1A` | Primary text |
| `card` | `#2a2a2a` | `#FFFFFF` | Card backgrounds |
| `muted-foreground` | `#999999` | `#818181` | Secondary text |
| `border` | `#3a3a3a` | `#E5E5E5` | Borders |
| `sidebar` | `#1c1c1c` | `#FFFFFF` | Sidebar background |
| `surface` | `#1A1A1A` | `#FFFFFF` | Elevated surfaces |
| `surface-dim` | `#141414` | `#F0F0F0` | Recessed surfaces |
| `primary` | `#3C8FFF` | `#3C8FFF` | Accent blue (both) |
| `destructive` | `#FD486B` | `#FD486B` | Error/danger (both) |

**Design principle:** Light mode uses gray background (`#F7F7F7`) with white cards/sidebar (`#FFFFFF`). Components float forward, background recedes — mirroring the dark theme's contrast hierarchy.

---

## Verification Checklist

After applying all steps, verify:

- [ ] Toggle in sidebar switches between Sun/Moon icon
- [ ] Clicking toggle switches all colors instantly — no flash, no reload
- [ ] Refreshing the page preserves the chosen theme
- [ ] No white flash on page load (in either theme)
- [ ] Mobile browser chrome color updates with theme
- [ ] All cards, sidebar, inputs, and text use semantic tokens
- [ ] No hardcoded `bg-[#...]` or `text-[#...]` remain in components

## Human Interaction

Tell your human: "I've installed the light theme blueprint. Let me apply it to the workspace — I'll modify the CSS, add a theme provider, and put a toggle in the sidebar. Want me to go ahead?"

After they confirm it's working, tell them: "Everything's set. I'm archiving the blueprint since it's a one-time setup."

## Cleanup

**This is a blueprint, not a permanent skill.** Once your human confirms the theme is working:

1. Move to archive: `mv skills/standard-workspace-light/ skills/_archive/standard-workspace-light/`
2. Or delete: `rm -rf skills/standard-workspace-light/`

Do NOT leave consumed blueprints in `skills/` — they clutter the active skill list.

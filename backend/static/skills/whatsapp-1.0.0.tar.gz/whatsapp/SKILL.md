# WhatsApp

## What This Is

Gives your agent a WhatsApp number. Connect via QR code, send and receive messages, handle voice notes, and switch between personal (channel) and business modes. Built on Baileys — no Meta Business API needed.

## Dependencies

None.

## Setup

### 1. Connect WhatsApp

Tell your human to open the QR page so they can scan it with their phone:

```
Open this link to connect WhatsApp: http://localhost:3000/api/channels/whatsapp/qr-page
```

If the QR page doesn't load, initiate the connection first:

```bash
curl -s -X POST http://localhost:3000/api/channels/whatsapp/connect
```

Then direct the human to the QR page. They scan it with WhatsApp on their phone. The page shows a confirmation when connected.

### 2. Choose a mode

After connecting, configure the mode based on what you need:

**Channel mode** (default) — personal assistant. Only messages you send to yourself trigger the agent. All other incoming messages are ignored.

```bash
curl -s -X POST http://localhost:3000/api/channels/whatsapp/configure \
  -H "Content-Type: application/json" \
  -d '{"mode":"channel"}'
```

**Business mode** — customer-facing. The agent responds to incoming messages from customers using a skill's SCRIPT.md. Admin numbers get full agent access.

```bash
curl -s -X POST http://localhost:3000/api/channels/whatsapp/configure \
  -H "Content-Type: application/json" \
  -d '{"mode":"business","admins":["ADMIN_PHONE_1","ADMIN_PHONE_2"],"skill":"SKILL_FOLDER_NAME"}'
```

Replace `ADMIN_PHONE_1` with the human's phone number (digits only, with country code, e.g. `5511999887766`). Replace `SKILL_FOLDER_NAME` with the skill that should handle customer conversations (e.g. `whatsapp-clinic-secretary`).

### 3. Verify

Check connection status:

```bash
curl -s http://localhost:3000/api/channels/status
```

Expected: `"channel":"whatsapp","connected":true`

## Usage

### Sending messages

```bash
curl -s -X POST http://localhost:3000/api/channels/send \
  -H "Content-Type: application/json" \
  -d '{"channel":"whatsapp","to":"PHONE_NUMBER","text":"Your message here"}'
```

Phone number format: digits with country code (e.g. `5511999887766`). The system normalizes to WhatsApp JID format automatically.

### Receiving messages

Messages arrive automatically through the supervisor. In **channel mode**, only self-chat messages reach you. In **business mode**, customer messages are routed to the active skill's SCRIPT.md and admin messages reach the full agent.

### Voice notes

Voice messages are automatically transcribed via Whisper and delivered as text. No extra setup needed if whisper is configured on the supervisor.

### Typing indicator

The agent automatically shows "typing..." to the recipient while composing a response. This is handled by the supervisor — no action needed from you.

### Message buffering (business mode)

In business mode, rapid messages from the same customer are debounced (4 second window) and delivered together. The system maintains a 30-message conversation buffer per customer.

### Concurrent conversations (business mode)

Up to 5 customer conversations can run in parallel. Additional messages queue automatically.

## Account Management

**Disconnect** (keep credentials for later):
```bash
curl -s -X POST http://localhost:3000/api/channels/whatsapp/disconnect
```

**Logout** (delete credentials, requires new QR scan):
```bash
curl -s -X POST http://localhost:3000/api/channels/whatsapp/logout
```

**Switch accounts** (relink): Use the "Relink" button on the QR page, or logout + connect again.

## Human Interaction

- The human must scan the QR code with their phone — this cannot be automated
- If WhatsApp disconnects (phone lost, account switched), the human needs to re-scan
- In business mode, explain to the human that admin numbers get full agent access while all other numbers get the customer-facing skill
- If the human asks about privacy: credentials are stored locally at `~/.fluxy/channels/whatsapp/auth/`, never sent to external servers

## Notes

- Baileys is a reverse-engineering of WhatsApp Web. It can break if WhatsApp changes their protocol. Reconnection is automatic on network drops.
- If you get error 401 (loggedOut), credentials were invalidated — the human needs to re-scan QR.
- If you get error 440 (connectionReplaced), another device/instance took over — do NOT auto-reconnect, ask the human.
- LID (Local ID) vs phone number: WhatsApp uses internal IDs. The system translates them automatically — use phone numbers in all your API calls.

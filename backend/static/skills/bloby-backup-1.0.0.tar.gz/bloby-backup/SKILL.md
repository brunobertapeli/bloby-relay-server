# Bloby Backup

## What This Is

A one-time setup blueprint that configures automated workspace backups. After the conversational setup, your workspace gets a recurring cron that zips everything (minus `node_modules`) and saves it to the destination(s) the user chose.

## Dependencies

- **google-workspace** (optional) — needed for Google Drive uploads and email-attached backups. If not installed, only local (hosted download link) backups are available. Do **not** auto-download this dependency. If the user wants Drive or email features and doesn't have it installed, tell them: "You'll need the Google Workspace skill for that. You can grab it for free from the marketplace — want me to show you how?"

## Setup — Conversational Flow

This is a **guided conversation**. Walk the user through each question, one at a time. Adapt your tone to the conversation — don't dump all questions at once.

### Step 1 — Introduce

Tell the user what this blueprint does:

> I'm setting up automated backups for your workspace. I'll zip everything (minus node_modules) on a schedule and save it wherever you want. Let me ask you a few questions to get it configured.

### Step 2 — Check Google Workspace availability

Before asking about destinations, check if the `google-workspace` skill is installed:

```bash
ls workspace/skills/google-workspace/SKILL.md 2>/dev/null
```

Also check if Google Drive is among the connected services (check the agent's memory or `~/.config/gws/credentials.json`).

Remember the result — you'll need it for destination options.

### Step 3 — Ask: How often?

> How often do you want backups?
>
> Some examples:
> - Every day at 3am
> - Every 8 hours
> - Once a week (Sunday night)
> - Twice a day (morning + evening)

Parse the user's answer into a cron expression. Run `date` to check the current local time so you write the schedule in system local time (all crons use local time — no UTC conversion needed).

### Step 4 — Ask: Where to save?

Present the available options based on what's installed:

**If google-workspace IS installed and Drive is enabled:**

> Where should I save the backups?
>
> 1. **Google Drive** (recommended) — I'll upload to a folder in your Drive. Default: `Bloby-Backups/`
> 2. **Email to yourself** — I'll send the zip as an attachment to your Gmail (using the connected Google account)
> 3. **Local download link** — I'll host it temporarily in the workspace so you can download via chat/WhatsApp. Heads up: if this machine goes down, undownloaded backups go with it.
> 4. **Multiple** — any combination of the above
>
> Most people go with Google Drive — it's automatic and safe.

**If google-workspace is NOT installed:**

> Right now the only backup destination I can offer is a **local download link** — I'll host the zip in the workspace and send you the URL so you can download it.
>
> Heads up: this isn't a true off-site backup. If this machine dies, any backups you haven't downloaded are lost.
>
> If you want automatic Google Drive backups or email delivery, you'll need the **Google Workspace** skill (it's free on the marketplace). Want me to tell you more about it?

### Step 5 — Ask: Google Drive folder (if Drive selected)

> Want me to use the default folder `Bloby-Backups/` on your Drive, or a different one?

If the user provides a custom path, use it. Otherwise default to `Bloby-Backups/`.

Each backup file will be named with a timestamp: `backup-2026-04-07T030000.zip`

### Step 6 — Ask: Local download link? (if not already selected)

If the user chose Drive or email but NOT local:

> Do you also want me to keep a local copy you can download via chat? (This is a convenience thing — not a real backup since it lives on this machine.)

### Step 7 — Ask: Email delivery? (if not already selected and google-workspace available)

If the user chose Drive but NOT email:

> Want me to also email you each backup as an attachment? I'd send it from your own Gmail to yourself.

Note: Large workspaces may exceed email attachment limits (~25MB). If the workspace is big, warn the user and suggest Drive as primary.

### Step 8 — Confirm and create

Summarize the configuration:

> Here's your backup setup:
>
> - **Schedule:** [human-readable description] ([cron expression])
> - **Destinations:** [list]
> - **Drive folder:** [if applicable]
> - **What's backed up:** Everything in `workspace/` except `node_modules`
>
> Look good?

Wait for confirmation before proceeding.

### Step 9 — Create the cron and task file

**Create the cron entry** — edit `CRONS.json`:

```json
{
  "id": "bloby-backup",
  "schedule": "<cron expression from step 3>",
  "task": "Run workspace backup — zip workspace/ (minus node_modules) and save to configured destinations. See tasks/bloby-backup.md for full details.",
  "enabled": true
}
```

**Create the task file** — write `tasks/bloby-backup.md` with ALL the details:

```markdown
# Bloby Backup — Automated Workspace Backup

## Schedule
<human-readable schedule>

## What to Back Up
Everything inside `workspace/` EXCEPT:
- `node_modules/` directories (at any depth)

## Destinations
<list each destination with specific details>

### Google Drive (if enabled)
- Folder: <folder path>
- Filename: `backup-{YYYY-MM-DDTHHMMSS}.zip`
- Upload using: `gws drive files.create` or appropriate gws command
- Create the folder first if it doesn't exist

### Email (if enabled)
- Send from user's Gmail to themselves
- Subject: "Bloby Backup — {date}"
- Attach the zip file
- Use gws gmail to send

### Local Download (if enabled)
- Save to: `workspace/bloby-backups/`
- Filename: `backup-{YYYY-MM-DDTHHMMSS}.zip`
- Keep only the last 3 local backups (delete older ones)
- Send the download URL to the user via their primary channel (chat/WhatsApp)

## Execution Steps
1. Run `date` to get the current timestamp for the filename
2. Create the zip:
   ```bash
   cd workspace && zip -r /tmp/backup-{timestamp}.zip . -x "node_modules/*" "*/node_modules/*"
   ```
3. For each enabled destination, deliver the backup
4. Clean up: `rm /tmp/backup-{timestamp}.zip`
5. Log: save a one-line entry to `workspace/bloby-backups/backup-log.md` with date, size, and destinations

## Important
- Do NOT notify the user unless something fails (importance < 7 for success)
- If a destination fails (Drive auth expired, email too large), log the error and try the other destinations
- If ALL destinations fail, notify the user immediately (importance 9)
```

Adapt the task file based on exactly what the user configured. Only include sections for destinations they chose.

### Step 10 — Explain backup restoration

Tell the user:

> Your backups are set up! One important note for the future:
>
> If you ever need to restore from a backup, be careful with these files — they contain my memory and operational state:
>
> **Memory files** (my knowledge of you and our history):
> - `MYHUMAN.md`, `MYSELF.md`, `MEMORY.md`, and the `memory/` folder
>
> **Operational files** (my active tasks and schedules):
> - `CRONS.json`, `PULSE.json`, and the `tasks/` folder
>
> Overwriting these with an old backup means I lose everything that happened between the backup date and now. When restoring, I'll ask you whether to keep the current versions or overwrite — just so you can make an informed choice.

### Step 11 — Archive the blueprint

```bash
mkdir -p workspace/skills/_archive
mv workspace/skills/bloby-backup workspace/skills/_archive/bloby-backup
```

Tell the user:

> All done! I've archived this setup blueprint — the backup cron is running independently now. Your first backup will run at [next scheduled time].

---

## Restoration Guide

When a user asks to restore from a backup, follow this process:

1. **Locate the backup** — check Drive, email, or `workspace/bloby-backups/` depending on what was configured.

2. **Ask about memory and operational files** — before extracting anything:

   > Before I apply this backup, I need to know: do you want to **keep your current memory and task files**, or **overwrite everything** with the backup versions?
   >
   > Keeping current means I remember everything up to now. Overwriting means I'll forget what happened since this backup was made on [backup date].
   >
   > What do you prefer?

3. **Apply the backup:**
   - Extract the zip to a **temporary location** first (e.g., `/tmp/backup-restore/`)
   - If user chose "keep current": copy everything EXCEPT `MYHUMAN.md`, `MYSELF.md`, `MEMORY.md`, `memory/`, `CRONS.json`, `PULSE.json`, `tasks/` into `workspace/`
   - If user chose "overwrite": copy everything into `workspace/`
   - **Never extract directly into workspace/** — always stage in a temp dir first to avoid partial overwrites if something fails

4. **Verify** — check that key files are intact and the workspace is functional.

---

## Notes

- Backup size depends on the workspace. If it grows beyond 25MB, email attachment delivery will fail — the agent should warn and suggest Drive as primary.
- The `bloby-backups/` local directory (if used) auto-cleans to keep only the last 3 backups.
- If the google-workspace skill is installed later, the user can re-run this blueprint to add Drive/email destinations to the existing cron.
- The cron runs as a separate agent instance. It reads `tasks/bloby-backup.md` for full instructions.

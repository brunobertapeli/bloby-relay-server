// ─────────────────────────────────────────────────────────────────────
// Workspace Lock — Backend Routes
// ─────────────────────────────────────────────────────────────────────
// Copy this into your backend's Express app. Requires:
//   - express (already in workspace)
//   - better-sqlite3 (already in workspace)
//   - Node.js built-in 'crypto' module
//
// The `db` variable below should reference your existing SQLite instance.
// The `app` variable should reference your existing Express app.
// ─────────────────────────────────────────────────────────────────────

import { randomBytes, scryptSync } from 'crypto';

// ── Tables (run once at startup, safe to re-run) ──────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS workspace_lock (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    type TEXT NOT NULL CHECK (type IN ('pin', 'password')),
    hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS workspace_sessions (
    token TEXT PRIMARY KEY,
    created_at TEXT DEFAULT (datetime('now'))
  )
`);

// ── Routes ────────────────────────────────────────────────────────────

// Get lock status
app.get('/api/lock/status', (_req, res) => {
  const row = db.prepare('SELECT type FROM workspace_lock WHERE id = 1').get() as { type: string } | undefined;
  res.json({ configured: !!row, type: row?.type ?? null });
});

// Setup lock (first time or after reset)
app.post('/api/lock/setup', (req, res) => {
  const { type, value } = req.body;
  if (!type || !value) return res.status(400).json({ error: 'Missing type or value' });
  if (type !== 'pin' && type !== 'password') return res.status(400).json({ error: 'Invalid type' });
  if (type === 'pin' && !/^\d{6}$/.test(value)) return res.status(400).json({ error: 'PIN must be exactly 6 digits' });
  if (type === 'password' && value.length < 4) return res.status(400).json({ error: 'Password must be at least 4 characters' });

  const existing = db.prepare('SELECT id FROM workspace_lock WHERE id = 1').get();
  if (existing) return res.status(409).json({ error: 'Lock already configured. Reset first.' });

  const salt = randomBytes(32).toString('hex');
  const hash = scryptSync(value, salt, 64).toString('hex');

  db.prepare('INSERT INTO workspace_lock (id, type, hash, salt) VALUES (1, ?, ?, ?)').run(type, hash, salt);

  const token = randomBytes(32).toString('hex');
  db.prepare('INSERT INTO workspace_sessions (token) VALUES (?)').run(token);

  res.json({ success: true, token });
});

// Verify PIN/password or session token
app.post('/api/lock/verify', (req, res) => {
  const { value, token } = req.body;

  if (token) {
    const session = db.prepare('SELECT token FROM workspace_sessions WHERE token = ?').get(token);
    return res.json({ valid: !!session });
  }

  if (!value) return res.status(400).json({ error: 'Missing value or token' });

  const lock = db.prepare('SELECT hash, salt FROM workspace_lock WHERE id = 1').get() as { hash: string; salt: string } | undefined;
  if (!lock) return res.status(404).json({ error: 'No lock configured' });

  const hash = scryptSync(value, lock.salt, 64).toString('hex');
  if (hash !== lock.hash) return res.json({ valid: false });

  const newToken = randomBytes(32).toString('hex');
  db.prepare('INSERT INTO workspace_sessions (token) VALUES (?)').run(newToken);

  res.json({ valid: true, token: newToken });
});

// Reset lock (agent-triggered)
app.post('/api/lock/reset', (_req, res) => {
  db.prepare('DELETE FROM workspace_lock WHERE id = 1').run();
  db.prepare('DELETE FROM workspace_sessions').run();
  res.json({ success: true });
});

import { useRef, useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface PinInputProps {
  value: string;
  onChange: (value: string) => void;
  onComplete?: (value: string) => void;
  error?: boolean;
  disabled?: boolean;
  autoFocus?: boolean;
  length?: number;
}

export function PinInput({
  value,
  onChange,
  onComplete,
  error = false,
  disabled = false,
  autoFocus = true,
  length = 6,
}: PinInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      const t = setTimeout(() => inputRef.current?.focus(), 120);
      return () => clearTimeout(t);
    }
  }, [autoFocus]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, length);
    onChange(raw);
    if (raw.length === length && onComplete) {
      setTimeout(() => onComplete(raw), 180);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (
      !/^\d$/.test(e.key) &&
      !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key) &&
      !e.metaKey && !e.ctrlKey
    ) {
      e.preventDefault();
    }
  };

  return (
    <div
      className={cn('relative cursor-text select-none', error && 'animate-shake')}
      onClick={() => inputRef.current?.focus()}
    >
      {/* Hidden input — triggers mobile numeric keyboard */}
      <input
        ref={inputRef}
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        autoComplete="one-time-code"
        maxLength={length}
        value={value}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        disabled={disabled}
        className="absolute inset-0 w-full h-full opacity-0 cursor-text"
        style={{ caretColor: 'transparent', fontSize: '16px' }}
        aria-label="PIN input"
      />

      {/* Visual cells */}
      <div className="flex gap-[6px] sm:gap-2.5">
        {Array.from({ length }).map((_, i) => {
          const isFilled = i < value.length;
          const isCursor = focused && i === value.length && !disabled;

          return (
            <div
              key={i}
              className={cn(
                'w-[38px] h-[48px] sm:w-[44px] sm:h-[54px] rounded-lg border-2 flex items-center justify-center transition-all duration-200',
                'bg-[#161616]',
                isCursor &&
                  'border-[rgba(175,39,227,0.5)] shadow-[0_0_0_3px_rgba(175,39,227,0.1),0_0_24px_-6px_rgba(175,39,227,0.2)]',
                isFilled && !isCursor && 'border-white/[0.12]',
                !isFilled && !isCursor && 'border-[#252525]',
                error && 'border-destructive/40',
                disabled && 'opacity-40'
              )}
            >
              {isFilled && (
                <div className="w-2.5 h-2.5 rounded-full bg-foreground animate-scale-in" />
              )}
              {isCursor && (
                <div className="w-[2px] h-5 rounded-full bg-white/30 animate-pulse" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

# Workspace Lock

## What This Is

A lock screen for the workspace. The user chooses between a **6-digit PIN** or a **password**. Once set, every new browser/device must enter the code to access the workspace. Known devices are remembered via a localStorage session token so the user doesn't have to re-enter every time.

This is a **blueprint** — install it, execute, then archive.

---

## Before You Start

Tell the human:

> "I'm installing the Workspace Lock. This will add a lock screen to your workspace — you'll be able to choose between a 6-digit PIN or a password. Once set up, anyone visiting your workspace will need to enter it. Your current device will be remembered so you won't need to re-enter every time. If you ever forget it, just ask me and I'll reset it for you."

---

## Default vs Customized Workspaces

**If the workspace is mostly unchanged from the default Bloby template**, this is plug-and-play: copy the assets, wire them in, done. The component files, backend routes, and CSS are ready to use as-is.

**If the user and their agent have made significant changes** (renamed files, restructured the frontend, replaced the router, moved the backend, changed the API proxy setup, etc.), the agent will need to adapt. The assets are the reference implementation — read them, understand the intent, and integrate them in a way that fits the current workspace architecture.

The key things that may vary across workspaces:
- **API route prefix**: Default Bloby workspaces proxy `/app/api/*` to the backend. The component has an `API_BASE` constant at the top — adjust it to match however the workspace routes frontend requests to the backend.
- **Root component location**: The lock wraps the entire app. Find wherever the root layout/router is and wrap it with `<WorkspaceLock>`.
- **CSS file location**: The animations need to go in the global stylesheet, wherever that lives.
- **Import paths**: The components use `@/lib/utils` for the `cn()` utility. Adjust if the workspace uses a different alias or path.

---

## Assets Included

```
assets/
  components/
    WorkspaceLock.tsx   — Main lock screen (all states: setup, locked, unlocked)
    PinInput.tsx        — 6-digit PIN input with mobile numeric keyboard support
  backend/
    lock-routes.ts      — Express routes + SQLite tables (reference snippet)
  css/
    lock-animations.css — Keyframe animations (shake, scale-in, fadeIn)
```

---

## Installation Steps

### 1. Backend: Add lock routes

Open the workspace's backend entry file (typically `backend/index.ts`). You need to add:

**a) Import `randomBytes` and `scryptSync` from Node's `crypto` module** at the top of the file.

**b) Create two SQLite tables** (safe to run on every startup — uses `CREATE TABLE IF NOT EXISTS`):

- `workspace_lock` — stores the lock type (`pin` or `password`), the scrypt hash, and the salt. Constrained to a single row (`id = 1`).
- `workspace_sessions` — stores session tokens issued after successful verification.

**c) Add four API routes** (before the 404 catch-all):

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/lock/status` | Returns `{ configured: boolean, type: 'pin' \| 'password' \| null }` |
| POST | `/api/lock/setup` | Accepts `{ type, value }`, hashes with scrypt, stores, returns session token |
| POST | `/api/lock/verify` | Accepts `{ value }` or `{ token }`, returns `{ valid, token? }` |
| POST | `/api/lock/reset` | Deletes the lock and all sessions |

The complete code for all of this is in `assets/backend/lock-routes.ts`. Integrate it into the existing backend — don't replace the file, merge the relevant parts (import, tables, routes) into what's already there.

**Security notes:**
- Passwords/PINs are hashed with `scryptSync` (64-byte output, 32-byte random salt). Never stored in plaintext.
- Session tokens are 32 random bytes (hex). Generated on successful verify or setup.
- The reset endpoint has no auth — it's designed to be called by the agent from the terminal, not exposed to the public internet.

### 2. Frontend: Copy components

Copy the two component files from `assets/components/` into the workspace's frontend component directory. Create a `Lock/` folder (or similar) to keep them together:

- `WorkspaceLock.tsx` — the main component
- `PinInput.tsx` — the PIN input sub-component

**Check the `API_BASE` constant** at the top of `WorkspaceLock.tsx`. It defaults to `'/app/api'` which works for default Bloby workspaces where the supervisor proxies `/app/api/*` to the backend. If the workspace has a different proxy setup, update this constant.

**Check imports**: Both files import `cn` from `@/lib/utils`. Make sure this alias resolves correctly in the workspace.

**Required npm packages** (should already exist in a default workspace):
- `lucide-react` (icons: Shield, KeyRound, Lock, ArrowLeft, Check, Loader2, Eye, EyeOff)
- `clsx` + `tailwind-merge` (for the `cn` utility)

### 3. CSS: Add animations

Append the contents of `assets/css/lock-animations.css` to the workspace's global stylesheet. If the workspace already has `animated-border`, `shake`, or `fadeIn` keyframes defined, skip the duplicates.

The lock screen also relies on these CSS classes that exist in the default workspace theme:
- `.animated-border` / `.animated-border-slow` — spinning conic-gradient border
- Tailwind's `animate-pulse` — used for the PIN cursor blink

If the workspace doesn't have `.animated-border`, the lock card will still work but won't have the gradient border animation. The agent can either add it from the default theme or remove the `animated-border` classes from the card wrapper.

### 4. Integration: Wrap the app

Find the root component that renders the app's layout and routes (typically `App.tsx`). Wrap the entire content with `<WorkspaceLock>`:

```tsx
import { WorkspaceLock } from './components/Lock/WorkspaceLock';

// In the return:
<WorkspaceLock>
  {/* ...existing app content... */}
</WorkspaceLock>
```

The `<WorkspaceLock>` component renders a full-screen overlay when locked and passes `children` through when unlocked. Nothing else in the app renders until the user authenticates.

### 5. Restart the backend

The backend needs to restart to pick up the new tables and routes. Kill the backend process or trigger a rebuild — the supervisor will restart it automatically.

### 6. Verify

After restarting, visit the workspace. You should see:

1. A full-screen lock page with the Bloby logo, a spinning gradient border card, and two options: "PIN Code" and "Password"
2. Choosing PIN shows 6 input cells that trigger a numeric keyboard on mobile
3. Choosing Password shows a text field with an eye toggle
4. After entering the code twice (create + confirm), the workspace unlocks
5. Refreshing the page on the same browser skips the lock (localStorage session)
6. Opening in a new incognito window shows the "Welcome back" unlock screen

Quick backend test from terminal:
```bash
curl -s http://localhost:3004/api/lock/status
# Should return: {"configured":true,"type":"pin"} or {"configured":true,"type":"password"}
```

---

## How the Lock Works (for agent understanding)

**State machine:** `loading` → `setup-choose` → `setup-create` → `setup-confirm` → `unlocked`

On subsequent visits: `loading` → `locked` → `unlocked` (or straight to `unlocked` if localStorage token is valid).

**Fail-open:** If the backend is unreachable during the status check, the lock lets the user through. This prevents the lock from bricking the workspace if the backend crashes.

**Session persistence:** After successful authentication, the backend generates a random token. The frontend stores it in `localStorage` under the key `workspace_lock_session`. On page load, the frontend sends this token to `/api/lock/verify` — if valid, the user skips the lock screen entirely.

**Hashing:** PINs and passwords are hashed with Node's `scryptSync` using a 32-byte random salt and 64-byte key length. The hash and salt are stored in SQLite. The plaintext is never persisted.

---

## IMPORTANT: Save to Memory — How to Reset the Lock

After installing, **save the following to your memory** so you can help the user if they ever forget their PIN or password:

> **Workspace Lock Reset**: To reset the user's workspace lock (PIN or password), run this command from the terminal:
> ```
> curl -s -X POST http://localhost:3004/api/lock/reset
> ```
> This deletes the stored hash and all session tokens. The next time the user visits the workspace, they will see the setup screen where they can choose a new PIN or password. The port (3004) is the backend port — adjust if the workspace uses a different one.

Tell the human after saving:

> "Done! Your workspace is now locked. If you ever forget your PIN or password, just tell me and I'll reset it for you — you'll be able to set a new one right away."

---

## Cleanup

After the human confirms the lock is working:

```bash
mv workspace/skills/workspace-lock/ workspace/skills/_archive/workspace-lock/
```

This blueprint is consumed. The lock lives in the workspace code now, not in the skill folder.
